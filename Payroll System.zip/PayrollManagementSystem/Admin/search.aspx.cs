﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PayrollManagementSystem.Admin
{
    public partial class search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*if (Session["login"].ToString() != "Admin")
            {
                Response.Redirect("../log.aspx");
            }*/

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.Text == "employeeid")
            {
                DropDownList2.Items.Clear();
                DropDownList2.DataSource = SqlDataSource1;
                DropDownList2.DataTextField = "employeeid";
                DropDownList2.DataValueField = "employeeid";
                DropDownList2.DataBind();
                DropDownList2.Items.Insert(0, "--Select--");

            }
            else if (DropDownList1.Text == "firstname")
            {
                DropDownList2.Items.Clear();
                DropDownList2.DataSource = SqlDataSource5;
                DropDownList2.DataTextField = "firstname";
                DropDownList2.DataValueField = "firstname";
                DropDownList2.DataBind();
                DropDownList2.Items.Insert(0, "--Select--");

            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.Text == "employeeid")
            {
                GridView2.DataSource = SqlDataSource2;
                GridView2.DataBind();

            }
            else if (DropDownList1.Text == "firstname")
            {
                GridView2.DataSource = SqlDataSource3;
                GridView2.DataBind();

            }
            Panel1.Visible = false;
            Panel2.Visible = true;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;

        }
    }
}