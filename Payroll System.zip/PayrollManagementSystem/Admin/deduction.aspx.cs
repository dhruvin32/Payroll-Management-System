﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PayrollManagementSystem.Admin
{
    public partial class deduction : System.Web.UI.Page
    {
        SqlConnection myconn;
        SqlCommand cmd;
        double bs;
        int el = 0, cl = 0, sl = 0;
        double final, tot, td;
        protected void Page_Load(object sender, EventArgs e)
        {
            myconn = new SqlConnection(WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            cmd = new SqlCommand();
            cmd.Connection = myconn;
            if (employeeid.Text != null)
            {
                String name = "select firstname,basesalary from Employee where employeeid='" + employeeid.Text + "'";
                myconn.Open();
                cmd.CommandText = name;
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    ename.Text = sdr["firstname"].ToString();
                    bsalary.Text = sdr["basesalary"].ToString();
                    bs = Double.Parse(sdr["basesalary"].ToString());
                    //bs = 1000;
                }
                sdr.Close();
                DateTime d1 = DateTime.Now;
                string month = d1.Month.ToString();
                string year = d1.Year.ToString();

                string l = "select el,sl,cl,(el+sl+cl) as 'total' from leave where employeeidleave=@em and year=@year and month=@month";
                cmd.Parameters.AddWithValue("@em", employeeid.Text);
                cmd.Parameters.AddWithValue("@year", year);
                cmd.Parameters.AddWithValue("@month", month);
                cmd.CommandText = l;
                SqlDataReader sdr1 = cmd.ExecuteReader();

                if (sdr1.Read())
                {
                    ltaken.Text = sdr1["total"].ToString();
                    el = Int32.Parse(sdr1["el"].ToString());
                    sl = Int32.Parse(sdr1["sl"].ToString());
                    cl = Int32.Parse(sdr1["cl"].ToString());
                }
                myconn.Close();
            }
        }

        protected void get_Click(object sender, EventArgs e)
        {
            double daily = (double)(bs / 30);
            double ededuct = (double)(el * daily);
            double sdeduct = 0;
            if (sl > 10)
                sdeduct = (double)((sl - 2) * (daily / 2));
             tot = ededuct + sdeduct;
            dleave.Text = tot.ToString();

           
            double pannum = (double)(bs * 12);
            if (pannum > 1000000)
            {
                td = (double)((112500 / 12) + (.3 * bs));
            }
            else if (pannum > 500000)
            {
                td = (double)((12500 / 12) + (.2) * bs);
            }
            else if (pannum > 250000)
            {
                td = (double)(.05 * bs);
            }
            else
            {
                td = 0;
            }
            tds.Text = td.ToString();
            double net = (double)(bs - td);
             final = tot + net;
            total.Text = final.ToString();
        }

        protected void deduct_Click(object sender, EventArgs e)
        {
            string insert = "insert into Deduction_details (emp_id_deducts,TDS,eleave,amount,month,year)";
            insert += "values (@emp,@tds,@eleave,@amount,@mo,@ye)";

            cmd.Parameters.AddWithValue("@emp", employeeid.Text);
            cmd.Parameters.AddWithValue("@tds", td);
            cmd.Parameters.AddWithValue("@eleave", tot);
            cmd.Parameters.AddWithValue("@amount", final);
            DateTime d1 = DateTime.Now;
            string month = d1.Month.ToString();
            string year = d1.Year.ToString();
            int m = Int32.Parse(month);
            int y = Int32.Parse(year);
            cmd.Parameters.AddWithValue("@mo", m);
            cmd.Parameters.AddWithValue("@ye", y);
            myconn.Open();
            cmd.CommandText = insert;
            cmd.ExecuteNonQuery();
            myconn.Close();
        }
    }
}