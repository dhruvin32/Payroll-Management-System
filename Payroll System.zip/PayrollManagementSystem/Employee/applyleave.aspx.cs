﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PayrollManagementSystem.Employee
{
    public partial class applyleave : System.Web.UI.Page
    {
        SqlConnection myconn;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            myconn = new SqlConnection(WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            cmd = new SqlCommand();
            cmd.Connection = myconn;
            String name = "select employeeid,firstname from Employee where employeeid='" + Session["username"] + "'";
            myconn.Open();
            cmd.CommandText = name;
            SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    employeeid.Text = sdr["employeeid"].ToString();
                    ename.Text = sdr["firstname"].ToString();
                }
            myconn.Close();

            /*if (edate.Text != null)
            {
                DateTime d1 = DateTime.Parse(sdate.Text);
                DateTime d2 = DateTime.Parse(edate.Text);
                double  result = (d2 - d1).TotalDays;
                duration.Text = result.ToString();
            }*/
        }

        protected void apply_Click(object sender, EventArgs e)
        {
            DateTime d1 = DateTime.Parse(sdate.Text);
            string month = d1.Month.ToString();
            string year = d1.Year.ToString();
            int m = Int32.Parse(month);
            int y = Int32.Parse(year);
            string update="";
            int du = Int32.Parse(duration.Text);
            if (leavetype.SelectedItem.Value == "cl")
            {
                update = "update leave set cl=cl+" + du + "where employeeidleave=@em and year=@year and month=@month";
                cmd.Parameters.AddWithValue("@em", employeeid.Text);
                cmd.Parameters.AddWithValue("@year", y);
                cmd.Parameters.AddWithValue("@month", m);
                myconn.Open();
                cmd.CommandText = update;
                int r = cmd.ExecuteNonQuery();
                if (r == 0)
                {
                    string insert = "insert into leave (employeeidleave,year,month,cl) values(@emp,@yearr,@monthh,@cll)";
                    cmd.Parameters.AddWithValue("@emp", employeeid.Text);
                    cmd.Parameters.AddWithValue("@yearr", y);
                    cmd.Parameters.AddWithValue("@monthh", m);
                    cmd.Parameters.AddWithValue("@cll", du);
                    cmd.CommandText = insert;
                    cmd.ExecuteNonQuery();
                }
                myconn.Close();
            }
            else if(leavetype.SelectedItem.Value=="sl")
            {
                update = "update leave set sl=sl+" + du + "where employeeidleave=@em1 and year=@year1 and month=@month1";
                cmd.Parameters.AddWithValue("@em1", employeeid.Text);
                cmd.Parameters.AddWithValue("@year1", y);
                cmd.Parameters.AddWithValue("@month1", m);
                myconn.Open();
                cmd.CommandText = update;
                int r = cmd.ExecuteNonQuery();
                if (r == 0)
                {
                    string insert = "insert into leave (employeeidleave,year,month,sl) values(@emp1,@yearr1,@monthh1,@cll1)";
                    cmd.Parameters.AddWithValue("@emp1", employeeid.Text);
                    cmd.Parameters.AddWithValue("@yearr1", y);
                    cmd.Parameters.AddWithValue("@monthh1", m);
                    cmd.Parameters.AddWithValue("@cll1", du);
                    cmd.CommandText = insert;
                    cmd.ExecuteNonQuery();
                }
                myconn.Close();
            }
            else
            {
                update = "update leave set el=el+" + du + "where employeeidleave=@em2 and year=@year2 and month=@month2";
                cmd.Parameters.AddWithValue("@em2", employeeid.Text);
                cmd.Parameters.AddWithValue("@year2", y);
                cmd.Parameters.AddWithValue("@month2", m);
                myconn.Open();
                cmd.CommandText = update;
                int r = cmd.ExecuteNonQuery();
                if (r == 0)
                {
                    string insert = "insert into leave (employeeidleave,year,month,el) values(@emp2,@yearr2,@monthh2,@cll2)";
                    cmd.Parameters.AddWithValue("@emp2", employeeid.Text);
                    cmd.Parameters.AddWithValue("@yearr2", y);
                    cmd.Parameters.AddWithValue("@monthh2", m);
                    cmd.Parameters.AddWithValue("@cll2", du);
                    cmd.CommandText = insert;
                    cmd.ExecuteNonQuery();
                }
                myconn.Close();

            }
        }
    }
}